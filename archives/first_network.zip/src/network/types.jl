using LightGraphs, SimpleWeightedGraphs

WeightedEdge = Union{Edge,SimpleWeightedEdge}